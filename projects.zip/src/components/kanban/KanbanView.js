// src/components/kanban/KanbanView.js
import { esc } from '../../utils/dom.js';
import { colorOf } from '../../utils/color.js';
import { fmtD, nowIso } from '../../utils/date.js';
import { cardFields, savePrefs } from '../../core/prefs.js';
import { ENT } from '../../core/state.js';
import { statFor, pri, emp, prj, stg } from '../../services/refs.js';
import { chipHtml } from '../table/renderers.js';
import { matchSearch } from '../table/filters.js';
import { getColDefs } from '../table/colDefs.js';
import { modal } from '../../ui/modal.js';
import { db, refreshAll } from '../../core/db.js';
import { setDbBeacon, afterChange } from '../../utils/logger.js';
import { toast } from '../../ui/toast.js';

function kbGroups(S, ent, by) {
  const unb = { id: null, name: 'Не назначено', color: '#98A2B3' };
  if (by === 'devId') return [...S.employees.filter(e => e.role === 'dev'), unb];
  if (by === 'agentId') return [...S.employees.filter(e => e.role === 'agent'), unb];
  if (by === 'priorityId') return [...S.priorities, unb];
  if (by === 'stageId') return [...S.stages, unb];
  return [...(ent === 'projects' ? S.projectStatuses : S.taskStatuses), unb];
}

export function openCardSettings(S, reRender) {
  const ents = ['projects', 'tasks', 'changes'];
  const NAMES = { num: 'Номер', name: 'Название', dates: 'Даты', status: 'Статус', priority: 'Приоритет', owner: 'Разработчик/Агент', project: 'Проект', stage: 'Этап' };

  modal({
    title: 'Поля карточек',
    sub: 'КАНБАН И ВРЕМЕННАЯ ШКАЛА',
    wide: true,
    body: `<div class="setgrid">${ents.map(ent => {
      const cf = cardFields(S, ent);
      return `<div class="setcard"><h3>${ENT[ent].ru}</h3>
        ${cf.all.map(f => `<label class="cb"><input type="checkbox" data-ent="${ent}" data-f="${f}" ${cf.list.includes(f) ? 'checked' : ''}> ${NAMES[f]}</label>`).join('')}</div>`;
    }).join('')}</div>`,
    foot: '<button class="btn pri" data-ok>Готово</button>',
    mount(box) {
      box.el.querySelectorAll('input[data-f]').forEach(i => i.onchange = async () => {
        const l = S.prefs.cards[i.dataset.ent];
        const f = i.dataset.f;
        S.prefs.cards[i.dataset.ent] = i.checked ? [...new Set([...l, f])] : l.filter(x => x !== f);
        await savePrefs(S);
      });
      box.el.querySelector('[data-ok]').onclick = () => {
        box.close();
        if (reRender) reRender();
      };
    }
  });
}

export function renderKanbanView(S, ent, mount, callbacks = {}) {
  const coldefs = getColDefs(S);
  const opts = ent === 'projects'
    ? [['statusId', 'Статус'], ['priorityId', 'Приоритет'], ['stageId', 'Этап'], ['devId', 'Разработчик (гл.)'], ['agentId', 'Агент (гл.)']]
    : [['statusId', 'Статус'], ['priorityId', 'Приоритет'], ['devId', 'Разработчик (гл.)'], ['agentId', 'Агент (гл.)']];

  const by = S.prefs.kanbanGroup[ent] || 'statusId';
  const groups = kbGroups(S, ent, by);
  let rows = S[ent].filter(r => matchSearch(S, coldefs, ent, r));
  const cf = cardFields(S, ent);

  const colsHtml = groups.map(g => {
    const items = rows.filter(r => (r[by] ?? null) === (g.id ?? null)).slice(0, 200);
    const cards = items.map(r => {
      const st = statFor(S, ent, r.statusId);
      const pr = pri(S, r.priorityId);
      const dv = emp(S, r.devId);
      const ag = emp(S, r.agentId);
      const pj = prj(S, r.projectId);
      const sg = stg(S, r.stageId);
      const own = by === 'devId' || by === 'agentId' ? emp(S, r[by]) : (dv || ag);

      let parts = '';
      if (cf.list.includes('num')) parts += `<div class="kn">${esc(r.num)}</div>`;
      if (cf.list.includes('name')) parts += `<div class="kt">${esc(r.name)}</div>`;
      let chips = '';
      if (cf.list.includes('status') && st) chips += chipHtml(st.name, colorOf(st));
      if (cf.list.includes('priority') && pr) chips += chipHtml(pr.name, colorOf(pr));
      if (cf.list.includes('stage') && sg) chips += chipHtml(sg.name, colorOf(sg));
      if (chips) parts += `<div class="krow">${chips}</div>`;
      if (cf.list.includes('dates') && r.start) parts += `<div class="krow"><span class="kdate">📅 ${fmtD(r.start)} → ${fmtD(r.end)}</span></div>`;
      if (cf.list.includes('owner') && own && by !== 'devId' && by !== 'agentId') parts += `<div class="krow">${chipHtml(own.name, colorOf(own))}</div>`;
      if (cf.list.includes('project') && pj && ent !== 'projects') parts += `<div class="kprj">▤ ${esc(pj.name)}</div>`;

      return `<div class="kcard" draggable="true" data-id="${r.id}" style="border-left:3px solid ${colorOf(st || pr || '#999')}">${parts}</div>`;
    }).join('');

    return `<div class="kb-col" data-gid="${g.id ?? ''}" style="--kc:${colorOf(g)}">
      <div class="kb-h"><span class="dot" style="background:${colorOf(g)}"></span><b>${esc(g.name)}</b><span class="n">${items.length}</span></div>
      <div class="kb-body">${cards || '<div style="color:var(--mut2);font-size:12px;text-align:center;padding:16px">пусто</div>'}</div></div>`;
  }).join('');

  mount.innerHTML = `<div class="panel" style="padding:14px;background:transparent;border:none;box-shadow:none">
    <div class="toolbar panel" style="margin-bottom:12px">
      <span style="font-size:12px;color:var(--mut);font-weight:700;letter-spacing:.06em;text-transform:uppercase">Группировка</span>
      <div class="seg" id="kbSeg">${opts.map(o => `<button data-by="${o[0]}" class="${o[0] === by ? 'on' : ''}">${o[1]}</button>`).join('')}</div>
      <div class="sp"></div>
      <button class="btn sm" data-cards>⚙ Поля карточек</button>
    </div>
    <div class="kb">${colsHtml}</div></div>`;

  const reRender = () => renderKanbanView(S, ent, mount, callbacks);

  mount.querySelector('[data-cards]').onclick = () => openCardSettings(S, reRender);
  mount.querySelectorAll('#kbSeg button').forEach(b => b.onclick = async () => {
    S.prefs.kanbanGroup[ent] = b.dataset.by;
    await savePrefs(S);
    reRender();
  });

  mount.querySelectorAll('.kcard').forEach(c => {
    c.onclick = () => { if (callbacks.onView) callbacks.onView(ent, +c.dataset.id); };
    c.addEventListener('dragstart', e => { e.dataTransfer.setData('text/kid', c.dataset.id); c.classList.add('drag'); });
    c.addEventListener('dragend', () => c.classList.remove('drag'));
  });

  mount.querySelectorAll('.kb-col').forEach(colEl => {
    colEl.addEventListener('dragover', e => { e.preventDefault(); colEl.classList.add('over'); });
    colEl.addEventListener('dragleave', () => colEl.classList.remove('over'));
    colEl.addEventListener('drop', async e => {
      e.preventDefault();
      colEl.classList.remove('over');
      const id = +e.dataTransfer.getData('text/kid');
      const r = S[ent].find(x => x.id === id);
      if (!r) return;
      const gid = colEl.dataset.gid ? +colEl.dataset.gid : null;
      r[by] = gid;
      r.updatedAt = nowIso();
      try {
        await db[ent].put(r);
        await refreshAll(S);
        await afterChange(S, callbacks.autoSave);
        toast(`«${r.name}» перемещен(а)`, 'ok');
        reRender();
      } catch (err) {
        setDbBeacon('error', '🔴 Ошибка базы данных');
        toast('Ошибка записи: ' + err.message, 'err');
      }
    });
  });
}
