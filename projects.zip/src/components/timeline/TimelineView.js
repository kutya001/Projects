// src/components/timeline/TimelineView.js
import { esc } from '../../utils/dom.js';
import { fmtD, todayISO, diffDays, addDays, MONTHS, toISO } from '../../utils/date.js';
import { colorOf, txtOn } from '../../utils/color.js';
import { cardFields, savePrefs } from '../../core/prefs.js';
import { statFor, pri, emp, stg } from '../../services/refs.js';
import { matchSearch } from '../table/filters.js';
import { getColDefs } from '../table/colDefs.js';
import { openCardSettings } from '../kanban/KanbanView.js';
import { popover, closePop } from '../../ui/popover.js';
import { setupTimelineDragDrop } from './dragDrop.js';

const PPD = { day: 44, month: 13, quarter: 4.5, year: 1.2 };
const MAXLANE = { day: 7, month: 4, quarter: 3, year: 2 };
const MODES = [['year', 'Годы'], ['quarter', 'Кварталы'], ['month', 'Месяцы'], ['day', 'Дни']];
const TL_ANCHOR = {};

function tlWindow(mode, anchor) {
  const a = new Date(anchor + 'T00:00:00');
  let ws, we;
  if (mode === 'day') {
    ws = new Date(a.getFullYear(), a.getMonth(), 1);
    we = new Date(a.getFullYear(), a.getMonth() + 1, 0);
  } else if (mode === 'month') {
    ws = new Date(a.getFullYear(), a.getMonth(), 1);
    we = new Date(a.getFullYear(), a.getMonth() + 3, 0);
  } else if (mode === 'quarter') {
    const q = Math.floor(a.getMonth() / 3);
    ws = new Date(a.getFullYear(), q * 3, 1);
    we = new Date(a.getFullYear(), q * 3 + 12, 0);
  } else {
    ws = new Date(a.getFullYear() - 1, 0, 1);
    we = new Date(a.getFullYear() + 3, 11, 31);
  }
  return { ws, we, days: Math.round((we - ws) / 864e5) + 1 };
}

function tlGroupDefs(S, ent, by) {
  const unb = { id: null, name: 'Не назначено', color: '#98A2B3' };
  if (by === 'dev') return [...S.employees.filter(e => e.role === 'dev'), unb];
  if (by === 'agent') return [...S.employees.filter(e => e.role === 'agent'), unb];
  if (by === 'priority') return [...S.priorities, unb];
  if (by === 'stage') return [...S.stages, unb];
  return [...(ent === 'projects' ? S.projectStatuses : S.taskStatuses), unb];
}

function tlMatch(by, g) {
  return r => {
    if (by === 'dev') return (r.devId ?? null) === (g.id ?? null);
    if (by === 'agent') return (r.agentId ?? null) === (g.id ?? null);
    if (by === 'priority') return (r.priorityId ?? null) === (g.id ?? null);
    if (by === 'stage') return (r.stageId ?? null) === (g.id ?? null);
    return (r.statusId ?? null) === (g.id ?? null);
  };
}

function barColor(S, ent, r, by) {
  if (by === 'priority') return colorOf(pri(S, r.priorityId));
  if (by === 'dev') return colorOf(emp(S, r.devId));
  if (by === 'agent') return colorOf(emp(S, r.agentId));
  if (by === 'stage') return colorOf(stg(S, r.stageId));
  return colorOf(statFor(S, ent, r.statusId));
}

export function renderTimelineView(S, ent, mount, callbacks = {}) {
  const coldefs = getColDefs(S);
  const mode = S.prefs.tlMode[ent] || 'month';
  const groupBy = S.prefs.tlGroup[ent] || (ent === 'projects' ? 'status' : 'dev');
  const colorBy = S.prefs.tlColor[ent] || 'status';
  const today = todayISO();

  if (!TL_ANCHOR[ent]) TL_ANCHOR[ent] = today;
  const { ws, we, days } = tlWindow(mode, TL_ANCHOR[ent]);
  const ppd = PPD[mode];
  const totalW = Math.round(days * ppd);
  const LEFTW = 220;

  let topSegs = [], botSegs = [];
  const pushSeg = (arr, label, d, cls) => arr.push({ label, d, cls });
  const d0 = new Date(ws);

  if (mode === 'day') {
    let cur = null, cnt = 0;
    for (let i = 0; i < days; i++) {
      const dd = new Date(d0); dd.setDate(dd.getDate() + i);
      const mk = dd.getFullYear() + '-' + MONTHS[dd.getMonth()];
      if (cur !== mk) { if (cur) pushSeg(topSegs, cur, cnt); cur = mk; cnt = 1; } else cnt++;
      const wd = dd.getDay();
      const cls = (wd === 0 || wd === 6 ? 'we ' : '') + (toISO(dd) === today ? 'tod' : '');
      pushSeg(botSegs, dd.getDate(), 1, cls);
    }
    pushSeg(topSegs, cur, cnt);
  } else if (mode === 'month') {
    let cy = null, cnt = 0;
    for (let i = 0; i < days; i++) {
      const dd = new Date(d0); dd.setDate(dd.getDate() + i);
      if (cy !== dd.getFullYear()) { if (cy !== null) pushSeg(topSegs, cy, cnt); cy = dd.getFullYear(); cnt = 1; } else cnt++;
    }
    pushSeg(topSegs, cy, cnt);
    let cm = null, cc = 0;
    for (let i = 0; i < days; i++) {
      const dd = new Date(d0); dd.setDate(dd.getDate() + i);
      const mk = MONTHS[dd.getMonth()] + ' ’' + String(dd.getFullYear()).slice(2);
      if (cm !== mk) { if (cm) pushSeg(botSegs, cm, cc); cm = mk; cc = 1; } else cc++;
    }
    pushSeg(botSegs, cm, cc);
  } else if (mode === 'quarter') {
    let cy = null, cnt = 0;
    for (let i = 0; i < days; i++) {
      const dd = new Date(d0); dd.setDate(dd.getDate() + i);
      if (cy !== dd.getFullYear()) { if (cy !== null) pushSeg(topSegs, cy, cnt); cy = dd.getFullYear(); cnt = 1; } else cnt++;
    }
    pushSeg(topSegs, cy, cnt);
    let cq = null, cc = 0;
    for (let i = 0; i < days; i++) {
      const dd = new Date(d0); dd.setDate(dd.getDate() + i);
      const q = Math.floor(dd.getMonth() / 3);
      const mk = 'Q' + (q + 1) + ' ’' + String(dd.getFullYear()).slice(2);
      if (cq !== mk) { if (cq) pushSeg(botSegs, cq, cc); cq = mk; cc = 1; } else cc++;
    }
    pushSeg(botSegs, cq, cc);
  } else {
    let cy = null, cnt = 0;
    for (let i = 0; i < days; i++) {
      const dd = new Date(d0); dd.setDate(dd.getDate() + i);
      if (cy !== dd.getFullYear()) { if (cy !== null) pushSeg(topSegs, cy, cnt); cy = dd.getFullYear(); cnt = 1; } else cnt++;
    }
    pushSeg(topSegs, cy, cnt);
    let cq = null, cc = 0;
    for (let i = 0; i < days; i++) {
      const dd = new Date(d0); dd.setDate(dd.getDate() + i);
      const mk = 'Q' + (Math.floor(dd.getMonth() / 3) + 1);
      if (cq !== mk) { if (cq) pushSeg(botSegs, cq, cc); cq = mk; cc = 1; } else cc++;
    }
    pushSeg(botSegs, cq, cc);
  }

  const segRow = (segs, bot) => `<div class="tl-hseg ${bot ? 'bot' : ''}">${segs.map(s => `<div class="${s.cls || ''}" style="width:${Math.round(s.d * ppd)}px;flex:none">${esc(String(s.label))}</div>`).join('')}</div>`;
  const gdefs = tlGroupDefs(S, ent, groupBy).map(g => ({ ...g, match: tlMatch(groupBy, g) }));
  const cf = cardFields(S, ent);

  let rowsHtml = '', rowMeta = [];
  const wsT = ws.getTime();

  gdefs.forEach((g, gi) => {
    const items = S[ent].filter(r => g.match(r) && r.start && matchSearch(S, coldefs, ent, r)).sort((a, b) => a.start < b.start ? -1 : 1);
    const laneEnd = [];
    const placed = items.map(it => {
      const s = new Date(it.start + 'T00:00:00').getTime();
      let li = laneEnd.findIndex(e => s >= e);
      if (li < 0) { li = laneEnd.length; laneEnd.push(0); }
      laneEnd[li] = new Date(it.end + 'T00:00:00').getTime() + 864e5;
      return { it, lane: li };
    });

    const maxL = MAXLANE[mode];
    const visible = placed.filter(p => p.lane < maxL);
    const hidden = placed.filter(p => p.lane >= maxL);
    const rowH = Math.max(1, Math.min(maxL, Math.max(1, laneEnd.length))) * 26 + 8;

    const bars = visible.map(({ it, lane }) => {
      const sT = new Date(it.start + 'T00:00:00').getTime(), eT = new Date(it.end + 'T00:00:00').getTime();
      if (eT < wsT || sT > we.getTime()) return '';
      const x = Math.max(0, Math.round((sT - wsT) / 864e5 * ppd));
      const w = Math.max(8, Math.round(diffDays(it.start, it.end) * ppd) - 2);
      const c = barColor(S, ent, it, colorBy);
      const st = statFor(S, ent, it.statusId);
      const label = (cf.list.includes('num') && w > 150 ? `<span class="bn">${esc(it.num)}</span>` : '') + esc(it.name);
      const title = `${it.num} · ${it.name}\n${fmtD(it.start)} → ${fmtD(it.end)} (${diffDays(it.start, it.end)} дн.)` + (st ? `\nСтатус: ${st.name}` : '');

      return `<div class="bar" data-id="${it.id}" data-s="${it.start}" data-e="${it.end}" title="${esc(title)}"
        style="left:${x}px;width:${w}px;top:${6 + lane * 26}px;background:linear-gradient(180deg,${c},${c}d9);color:${txtOn(c)}">
        <span class="hnd l" data-h="l"></span><span style="overflow:hidden;text-overflow:ellipsis">${label}</span><span class="hnd r" data-h="r"></span></div>`;
    }).join('');

    rowsHtml += `<div class="tl-row" data-gi="${gi}">
      <div class="tl-left" style="height:${rowH}px"><span class="dot" style="background:${colorOf(g)}"></span>
        <span><span class="nm">${esc(g.name)}</span><br><span class="ct">${items.length} зап.</span></span>
        ${hidden.length ? `<span class="more" data-gi="${gi}" title="Не поместились в видимую область">+${hidden.length}</span>` : ''}</div>
      <div class="tl-canvas" data-gi="${gi}" style="width:${totalW}px;height:${rowH}px">${bars || '<span class="emptyrow">нет записей в периоде</span>'}</div></div>`;

    rowMeta.push({ g, hidden: hidden.map(h => h.it), top: 0, h: rowH });
  });

  const todayX = Math.round(diffDays(toISO(ws), today) * ppd);
  mount.innerHTML = `
   <div class="tl-tools">
     <div class="seg" id="tlMode">${MODES.map(m => `<button data-m="${m[0]}" class="${m[0] === mode ? 'on' : ''}">${m[1]}</button>`).join('')}</div>
     <div class="seg" id="tlGroup">
       <button data-g="dev" class="${groupBy === 'dev' ? 'on' : ''}">По разработчикам</button>
       <button data-g="agent" class="${groupBy === 'agent' ? 'on' : ''}">По агентам</button>
       <button data-g="status" class="${groupBy === 'status' ? 'on' : ''}">По статусу</button>
       <button data-g="priority" class="${groupBy === 'priority' ? 'on' : ''}">По приоритету</button>
       ${ent === 'projects' ? `<button data-g="stage" class="${groupBy === 'stage' ? 'on' : ''}">По этапу</button>` : ''}
     </div>
     <select id="tlColor" style="width:auto;padding:7px 10px">
       <option value="status" ${colorBy === 'status' ? 'selected' : ''}>Цвет: Статус</option>
       <option value="priority" ${colorBy === 'priority' ? 'selected' : ''}>Цвет: Приоритет</option>
       <option value="dev" ${colorBy === 'dev' ? 'selected' : ''}>Цвет: Разработчик</option>
       <option value="agent" ${colorBy === 'agent' ? 'selected' : ''}>Цвет: Агент</option>
       ${ent === 'projects' ? `<option value="stage" ${colorBy === 'stage' ? 'selected' : ''}>Цвет: Этап</option>` : ''}
     </select>
     <button class="btn sm" data-nav="-1">◀</button>
     <button class="btn sm" data-today>Сегодня</button>
     <button class="btn sm" data-nav="1">▶</button>
     <button class="btn sm" data-cards>⚙ Карточки</button>
     <span class="hint">Перетаскивайте полосы по дате и между строками · за края — растянуть · клик — карточка</span>
   </div>
   <div class="tl-scroll">
     <div style="min-width:${LEFTW + totalW}px;position:relative">
       <div class="tl-headrow">
         <div class="tl-corner" style="width:${LEFTW}px;min-width:${LEFTW}px;flex:none">${groupBy === 'dev' ? 'Разработчик (гл.)' : groupBy === 'agent' ? 'Агент (гл.)' : groupBy === 'priority' ? 'Приоритет' : groupBy === 'stage' ? 'Этап' : 'Статус'}</div>
         <div class="tl-hc" style="width:${totalW}px;flex:none">${segRow(topSegs)}${segRow(botSegs, true)}</div>
       </div>
       <div id="tlBody" style="position:relative">${rowsHtml}
         ${todayX >= 0 && todayX <= totalW ? `<div class="tl-today" style="left:${LEFTW + todayX}px"></div>` : ''}
       </div>
     </div>
   </div>`;

  const reRender = () => renderTimelineView(S, ent, mount, callbacks);

  mount.querySelectorAll('#tlMode button').forEach(b => b.onclick = async () => {
    S.prefs.tlMode[ent] = b.dataset.m;
    await savePrefs(S);
    reRender();
  });

  mount.querySelectorAll('#tlGroup button').forEach(b => b.onclick = async () => {
    S.prefs.tlGroup[ent] = b.dataset.g;
    await savePrefs(S);
    reRender();
  });

  mount.querySelector('#tlColor').onchange = async e => {
    S.prefs.tlColor[ent] = e.target.value;
    await savePrefs(S);
    reRender();
  };

  mount.querySelector('[data-cards]').onclick = () => openCardSettings(S, reRender);
  mount.querySelector('[data-today]').onclick = () => { TL_ANCHOR[ent] = today; reRender(); };

  mount.querySelectorAll('[data-nav]').forEach(b => b.onclick = () => {
    const dir = +b.dataset.nav;
    const step = { day: 31, month: 92, quarter: 182, year: 365 }[mode] * dir;
    TL_ANCHOR[ent] = addDays(TL_ANCHOR[ent], step);
    reRender();
  });

  mount.querySelectorAll('.tl-hseg.bot div').forEach(seg => seg.onclick = () => {
    if (mode === 'year') S.prefs.tlMode[ent] = 'quarter';
    else if (mode === 'quarter') S.prefs.tlMode[ent] = 'month';
    else if (mode === 'month') S.prefs.tlMode[ent] = 'day';
    else return;
    savePrefs(S);
    reRender();
  });

  mount.querySelectorAll('.more').forEach(m => m.onclick = e => {
    e.stopPropagation();
    const gi = +m.dataset.gi;
    const rm = rowMeta[gi];
    popover(m, `<div class="pt">${esc(rm.g.name)}: еще ${rm.hidden.length} не поместилось</div>
      <div style="max-height:240px;overflow:auto;min-width:240px">
      ${rm.hidden.map(it => {
        const c = barColor(S, ent, it, colorBy);
        return `<div class="pi" data-id="${it.id}"><span class="dot" style="background:${c}"></span><span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(it.num)} · ${esc(it.name)}</span><span class="mono" style="color:var(--mut)">${fmtD(it.start)}</span></div>`;
      }).join('')}</div>
      <div class="pact"><button class="btn sm" data-zoom>🔍 Показать по дням</button></div>`,
      p => {
        p.querySelectorAll('.pi').forEach(pi => pi.onclick = () => {
          closePop();
          if (callbacks.onView) callbacks.onView(ent, +pi.dataset.id);
        });
        p.querySelector('[data-zoom]').onclick = async () => {
          S.prefs.tlMode[ent] = 'day';
          TL_ANCHOR[ent] = rm.hidden[0]?.start || today;
          await savePrefs(S);
          closePop();
          reRender();
        };
      });
  });

  setupTimelineDragDrop(S, ent, mount, reRender, rowMeta, groupBy, ppd, callbacks);
}
