// src/pages/refs.js
import { esc } from '../utils/dom.js';
import { REFTABS } from '../core/state.js';
import { db, refreshAll } from '../core/db.js';
import { confirmBox } from '../ui/modal.js';
import { afterChange, setDbBeacon } from '../utils/logger.js';
import { toast } from '../ui/toast.js';
import { renderTableView } from '../components/table/TableView.js';

let curTab = 'employees';

export function renderRefsPage(S, mount, callbacks = {}) {
  const tabs = REFTABS.map(([k, name]) => `
    <button data-tab="${k}" class="${curTab === k ? 'on' : ''}">${esc(name)} (${(S[k] || []).length})</button>
  `).join('');

  mount.innerHTML = `
    <div class="phead">
      <div><div class="kick">Системные справочники</div><h1>Справочники</h1></div>
      <div class="sp"></div>
      <button class="btn pri" id="btnAddRef">+ Добавить элемент</button>
    </div>
    <div class="refs">
      <div class="tabs">${tabs}</div>
      <div id="refPanel"></div>
    </div>`;

  const panelEl = mount.querySelector('#refPanel');
  const reRender = () => renderRefsPage(S, mount, callbacks);

  mount.querySelectorAll('.tabs button').forEach(b => b.onclick = () => {
    curTab = b.dataset.tab;
    reRender();
  });

  mount.querySelector('#btnAddRef').onclick = () => {
    if (callbacks.onAddDir) callbacks.onAddDir(curTab);
  };

  const refCallbacks = {
    onView: (ent, id) => {
      if (callbacks.onView) callbacks.onView(ent, id);
    },
    onEdit: (ent, id) => {
      if (callbacks.onEditDir) callbacks.onEditDir(ent, id);
    },
    onDelete: (ent, id) => {
      confirmBox('Удалить эту запись из справочника?', async () => {
        try {
          await db[ent].delete(id);
          await refreshAll(S);
          await afterChange(S, callbacks.autoSave);
          toast('Запись удалена из справочника', 'ok');
          reRender();
        } catch (e) {
          setDbBeacon('error', '🔴 Ошибка базы данных');
          toast('Ошибка удаления', 'err');
        }
      });
    }
  };

  renderTableView(S, curTab, panelEl, refCallbacks);
}

